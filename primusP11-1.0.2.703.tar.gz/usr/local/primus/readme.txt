Primus PKCS#11 Test
===================

configuration
-------------
Edit /usr/local/primus/etc/primus.cfg

Run
---
./gTestP11 --help
./gTestP11 --pin=XXXXXXXX --datafile=/tmp/test.data

Optionally, set SECUROSYS_PKCS11_CONF to the configuration file
to override default